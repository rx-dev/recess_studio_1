execute if entity @s[type=zombie,tag=infection.zombie] run function recess:infection/mob/zombie/tick
execute if entity @s[type=item_display,tag=infection.slime_display] run function recess:infection/mob/slime/tick_display
execute if entity @s[type=slime,tag=infection.slime] run function recess:infection/mob/slime/tick_slime
execute if entity @s[type=skeleton,tag=infection.skeleton] run function recess:infection/mob/skeleton/tick
execute if entity @s[type=marker,tag=infection.zombie_cough] run function recess:infection/mob/zombie/cough_tick
execute if entity @s[type=wandering_trader,tag=infection.ghost_brain] run function recess:infection/mob/ghost/tick
execute if entity @s[type=marker,tag=infection.ghost_trail] run function recess:infection/mob/ghost/trail_tick
execute if entity @s[type=item_display,tag=infection.ghost_moss_display] run function recess:infection/mob/ghost/moss/tick
