tag @s remove self
