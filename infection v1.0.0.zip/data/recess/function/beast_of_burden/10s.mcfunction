execute as @e[type=zombie,tag=recess.beast_of_burden] at @s run function recess:beast_of_burden/entity/10s
